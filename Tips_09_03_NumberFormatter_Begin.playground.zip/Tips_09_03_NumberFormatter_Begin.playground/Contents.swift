//
//  A Demo for iOS Development Tips Weekly
//  by Steven Lipton (C)2020, All rights reserved
// Check out the video series on LinkedIn Learning at https://linkedin-learning.pxf.io/YxZgj
//  For code go to http://bit.ly/AppPieGithub


//:# Number Formatter Demo
import Foundation

//: Number formatter works in NSNumber, so I cast our demo values accordingly.
let pi = NSNumber(value:Double.pi)
let x = NSNumber(value:-3.00004567)
let money = NSNumber(value:3141592653.5999345)

//: Declare the formatter


